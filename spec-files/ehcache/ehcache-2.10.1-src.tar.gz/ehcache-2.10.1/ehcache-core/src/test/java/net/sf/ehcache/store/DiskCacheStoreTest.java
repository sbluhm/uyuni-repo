package net.sf.ehcache.store;

import org.junit.Test;

/**
 * @author Alex Snaps
 */
public class DiskCacheStoreTest {

    @Test
    public void testUnpinFlushes() {
//        DiskCacheStore store = new DiskCacheStore(new OnHeapCachingTier<Object, Element>(10), DiskStore.create(), );
    }
}
