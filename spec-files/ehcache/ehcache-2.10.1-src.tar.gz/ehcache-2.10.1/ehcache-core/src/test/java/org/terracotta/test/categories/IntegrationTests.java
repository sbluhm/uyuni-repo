package org.terracotta.test.categories;

/**
 * @author Alex Snaps
 */
public enum IntegrationTests {
}
