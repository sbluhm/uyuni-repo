/*
 * All content copyright (c) 2003-2012 Terracotta, Inc., except as may otherwise be noted in a separate copyright
 * notice. All rights reserved.
 */
package net.sf.ehcache.management.service.impl;

import org.terracotta.management.l1bridge.RemoteAgentEndpoint;

/**
 * @author Ludovic Orban
 */
public interface DfltSamplerRepositoryServiceMBean extends RemoteAgentEndpoint {
}
