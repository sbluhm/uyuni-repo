package net.sf.ehcache.management.service;

public interface SamplerRepositoryService extends ManagementServerLifecycle {
}