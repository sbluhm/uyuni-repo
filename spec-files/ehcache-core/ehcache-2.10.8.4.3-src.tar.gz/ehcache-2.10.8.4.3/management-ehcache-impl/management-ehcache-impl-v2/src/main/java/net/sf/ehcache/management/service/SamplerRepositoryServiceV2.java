package net.sf.ehcache.management.service;

public interface SamplerRepositoryServiceV2 extends ManagementServerLifecycle {

}
