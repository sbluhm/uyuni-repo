CREATE TYPE address AS (street text, city text, state char(2), zip text);
