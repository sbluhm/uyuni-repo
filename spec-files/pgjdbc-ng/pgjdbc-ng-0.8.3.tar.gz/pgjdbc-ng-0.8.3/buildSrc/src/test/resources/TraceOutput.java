package com.impossibl.jdbc.spy;

// Shell for compilation test
public interface TraceOutput {

  void trace(Trace trace);

}
