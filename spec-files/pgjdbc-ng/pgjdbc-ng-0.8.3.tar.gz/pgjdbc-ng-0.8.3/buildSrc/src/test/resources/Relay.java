package com.impossibl.jdbc.spy;

// Shell for compilation test
public interface Relay<T> {

  T getTarget();

}
