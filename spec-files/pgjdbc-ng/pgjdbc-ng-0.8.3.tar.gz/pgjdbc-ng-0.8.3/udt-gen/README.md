# UDT Generator

UDT Generator is a Java code generator for generated JDBC compliant classes for PostgreSQL composite types.

See the [User Guide](https://impossibl.github.io/pgjdbc-ng/docs/current/user-guide#udt-generator)
