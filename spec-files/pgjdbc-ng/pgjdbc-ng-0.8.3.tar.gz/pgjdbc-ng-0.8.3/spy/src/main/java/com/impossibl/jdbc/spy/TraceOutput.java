package com.impossibl.jdbc.spy;

public interface TraceOutput {

  void trace(Trace trace);

}
