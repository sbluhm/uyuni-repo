# Spy - JDBC Interceptor

Spy is a JDBC API interceptoin facility using auto-generated relay & listener classes.

See the [User Guide](https://impossibl.github.io/pgjdbc-ng/docs/current/user-guide#spy)
