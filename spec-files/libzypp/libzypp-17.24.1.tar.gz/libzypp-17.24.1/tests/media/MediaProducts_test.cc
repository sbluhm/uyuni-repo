#include <iostream>
#include <boost/test/unit_test.hpp>

#include <zypp/MediaProducts.h>

BOOST_AUTO_TEST_CASE(compile)
{
  // make sure header compiles
}
