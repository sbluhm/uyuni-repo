passphrase for the key pair is zypp-devel

