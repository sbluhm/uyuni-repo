package com.onelogin.saml2.exception;

public class XMLEntityException extends Exception {

	private static final long serialVersionUID = 1L;

	public XMLEntityException(String message) {
		super(message);
	}

}
