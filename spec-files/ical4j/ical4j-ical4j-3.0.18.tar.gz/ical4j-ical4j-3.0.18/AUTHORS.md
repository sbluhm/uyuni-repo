=======================
 iCal4j - Contributors
=======================

Please refer to [GitHub](https://github.com/ical4j/ical4j/graphs/contributors) for a full list of contributors to the ical4j project.

 Many thanks to the following people for their contributions and feedback:
 
  - Heladito, Darkwave, twinkle, Outmyth, Ralph Schaer, Chris Borrill,
  Meher Tendjoukian, John Casey, Harrie Hazewinkel, Markus Rahlff,
  Marcus Hauer, Dustin (calibre), Tobias Lidskog, Bruce Atherton,
  Mike Douglass, Fredrik Bertilsson ...
 
 
 Thanks also to the developers of the following tools/libraries:
 
  - eclipse [http://eclipse.org/]
  
  - eclipse checkstyle plugin [http://eclipse-cs.sourceforge.net/]
  
  - Apache Commons Logging/Log4j [http://jakarta.apache.org/commons/logging/]
  
  - Apache Commons Codec [http://jakarta.apache.org/commons/codec/]
  
  - Apache Ant [http://ant.apache.org/]
  
  - JUnit [http://junit.org/]
  
  - Base64 [http://iharder.sourceforge.net/base64/]
  
  - Vzic [http://dspace.dial.pipex.com/prod/dialspace/town/pipexdsl/s/asbm26/vzic/]
  
  - Cenqua [http://cenqua.com] for Clover and the Open Source license
