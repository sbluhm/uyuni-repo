package net.fortuna.ical4j.validate;

/**
 * Created by fortuna on 12/09/15.
 */
public final class EmptyValidator<T> implements Validator<T> {

    private static final long serialVersionUID = 1L;

    public void validate(T target) throws ValidationException {
        // TODO Auto-generated method stub

    }
}
