#!/usr/bin/env bash
./gradlew wrapper --gradle-version=4.9 --distribution-type=bin
