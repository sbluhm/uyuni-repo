package de.neuland.jade4j.lexer.token;

public class ForTag extends Token {

    public ForTag(String value, int lineNumber) {
        super(value, lineNumber);
    }

}
