package de.neuland.jade4j.lexer.token;


public class Tag extends Token {

    public Tag(String value, int lineNumber) {
        super(value, lineNumber);
    }

}
