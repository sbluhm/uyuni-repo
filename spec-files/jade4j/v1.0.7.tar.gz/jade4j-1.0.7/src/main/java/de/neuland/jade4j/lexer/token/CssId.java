package de.neuland.jade4j.lexer.token;

public class CssId extends Token {

	public CssId(String value, int lineNumber) {
		super(value, lineNumber);
	}

}
