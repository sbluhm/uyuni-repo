package de.neuland.jade4j.lexer.token;


public class Text extends Token {

	public Text(String value, int lineNumber) {
		super(value, lineNumber);
	}

}
