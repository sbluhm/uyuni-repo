package de.neuland.jade4j.lexer.token;

public class UnbufferedComment extends Token {

    public UnbufferedComment(String value, int lineNumber) {
        super(value, lineNumber);
    }

}
