package de.neuland.jade4j.lexer.token;


public class Default extends Token {

	public Default(String value, int lineNumber) {
		super(value, lineNumber);
	}

}
