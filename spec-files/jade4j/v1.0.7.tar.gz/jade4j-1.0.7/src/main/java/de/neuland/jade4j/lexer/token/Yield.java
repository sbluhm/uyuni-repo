package de.neuland.jade4j.lexer.token;


public class Yield extends Token {
    public Yield(String value, int lineNumber) {
        super(value, lineNumber);
    }

}
