package de.neuland.jade4j.lexer.token;


public class Colon extends Token {

	public Colon(String value, int lineNumber) {
		super(value, lineNumber);
	}

}
