package de.neuland.jade4j.lexer.token;


public class Outdent extends Token {

	public Outdent(String value, int lineNumber) {
		super(value, lineNumber);
	}

}
