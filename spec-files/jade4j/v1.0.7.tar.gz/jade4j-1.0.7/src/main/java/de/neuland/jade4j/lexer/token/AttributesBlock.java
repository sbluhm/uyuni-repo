package de.neuland.jade4j.lexer.token;

public class AttributesBlock extends Token {
    public AttributesBlock(String value, int lineNumber) {
        super(value, lineNumber);
    }
}
