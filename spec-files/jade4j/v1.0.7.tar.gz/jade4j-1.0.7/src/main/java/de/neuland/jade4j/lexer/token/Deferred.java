package de.neuland.jade4j.lexer.token;

public class Deferred extends Token {

	public Deferred(String value, int lineNumber) {
		super(value, lineNumber);
	}

}
