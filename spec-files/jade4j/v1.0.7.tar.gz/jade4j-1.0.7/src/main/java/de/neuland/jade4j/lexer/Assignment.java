package de.neuland.jade4j.lexer;

import de.neuland.jade4j.lexer.token.Token;

public class Assignment extends Token {

	public Assignment(String value, int lineNumber) {
		super(value, lineNumber);
	}

}
