package de.neuland.jade4j.lexer.token;

/**
 * Created by christoph on 14.10.15.
 */
public class Interpolation extends Token {
    public Interpolation(String value, int lineNumber) {
        super(value, lineNumber);
    }
}
