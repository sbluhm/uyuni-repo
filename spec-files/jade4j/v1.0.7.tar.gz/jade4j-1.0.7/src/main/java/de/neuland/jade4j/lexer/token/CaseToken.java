package de.neuland.jade4j.lexer.token;


public class CaseToken extends Token {


	public CaseToken(String value, int lineNumber) {
		super(value, lineNumber);
	}

}
