package de.neuland.jade4j.lexer.token;

public class Indent extends Token {

	public Indent(String value, int lineNumber) {
		super(value, lineNumber);
	}

}
