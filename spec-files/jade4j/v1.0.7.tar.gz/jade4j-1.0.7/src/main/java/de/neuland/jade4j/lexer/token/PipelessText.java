package de.neuland.jade4j.lexer.token;

import java.util.ArrayList;

public class PipelessText extends Token {

    public PipelessText(String value, int lineNumber) {
        super(value, lineNumber);
    }
}
