package de.neuland.jade4j.lexer.token;

public class Else extends Token {

	public Else(String value, int lineNumber) {
		super(value, lineNumber);
	}
}
