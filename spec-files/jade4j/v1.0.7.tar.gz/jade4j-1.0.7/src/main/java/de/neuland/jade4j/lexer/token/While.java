package de.neuland.jade4j.lexer.token;

public class While extends Token {
	public While(String value, int lineNumber) {
		super(value, lineNumber);
	}
}
