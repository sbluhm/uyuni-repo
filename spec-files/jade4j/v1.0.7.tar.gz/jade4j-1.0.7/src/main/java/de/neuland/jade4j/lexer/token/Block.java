package de.neuland.jade4j.lexer.token;

public class Block extends Token {

    public Block(String value, int lineNumber) {
        super(value, lineNumber);
    }

}
