package de.neuland.jade4j.lexer.token;


public class Doctype extends Token {
    public Doctype(String value, int lineNumber) {
        super(value, lineNumber);
    }

}
