package de.neuland.jade4j.lexer.token;


public class Eos extends Token {

	public Eos(String value, int lineNumber) {
		super(value, lineNumber);
	}

}
