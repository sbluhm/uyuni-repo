package de.neuland.jade4j.lexer.token;


public class When extends Token {

	public When(String value, int lineNumber) {
		super(value, lineNumber);
	}

}
