package de.neuland.jade4j.lexer.token;

public class CssClass extends Token {

	public CssClass(String value, int lineNumber) {
		super(value, lineNumber);
	}

}
