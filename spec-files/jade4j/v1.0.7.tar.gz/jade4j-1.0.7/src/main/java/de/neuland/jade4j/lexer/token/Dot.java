package de.neuland.jade4j.lexer.token;


public class Dot extends Token {

	public Dot(String value, int lineNumber) {
		super(value, lineNumber);
	}

}
