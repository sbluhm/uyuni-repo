package de.neuland.jade4j.lexer.token;

public class MixinBlock extends Token {
    public MixinBlock(String value, int lineNumber) {
        super(value, lineNumber);
    }
}
