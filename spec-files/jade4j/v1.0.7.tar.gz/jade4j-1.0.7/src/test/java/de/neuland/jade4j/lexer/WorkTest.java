package de.neuland.jade4j.lexer;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import de.neuland.jade4j.lexer.token.TokenTest;

public class WorkTest extends TokenTest {

    @Test
    public void testMe() {
        assertTrue(true);
    }

}
