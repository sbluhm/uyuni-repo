package de.neuland.jade4j.lexer;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class LexerTest {

    @SuppressWarnings("unused")
    private Lexer lexer;

    @Test
    public void test() {
//        try {
//            lexer = new Lexer(null, null);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
        assertTrue(true);
    }
    
    

}
