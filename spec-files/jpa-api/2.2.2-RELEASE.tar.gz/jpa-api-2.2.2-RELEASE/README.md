# Java Persistence API specification

This is collaboration repository for Eclipse Project for JPA: https://projects.eclipse.org/projects/ee4j.jpa

For discussions join [jpa-dev@eclipse.org](https://dev.eclipse.org/mailman/listinfo/jpa-dev) mailing list
